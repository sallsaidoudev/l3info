package fr.istic.prg1.list.util;

public interface SuperT {
	public abstract SuperT clone();
	public abstract boolean equals(Object o);
	public abstract String toString();
}
